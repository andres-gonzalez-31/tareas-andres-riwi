print("="*40)
print("Bienvenido a tu calculador de nota")
print("="*40,"\n")
#comienzo inicialisando una lista vacia que me va a servir mas a bajo,
# como lo dice su nombre para almacenar las notas del usuario.
lista_de_notas = []

# lo coloque como un paso adicional para que sea mas interactivo con el usuario,
#  ya que despues de ingresar el nombre, ese va a parecer en cada parte del programa çuando se le haga una pregunta.
ingresa_nombre = input("ingresa tu nombre: ").upper()

print("\n")
print("="*50)
print(f"Bienvenido a tu calculador de nota => {ingresa_nombre} ")
print("="*50,"\n")


# te pide que ingrese cuantas notas deseas ingresar solo con numeros, si ingresas un valor no numerico te manda un error
while True:
    try:
        notas_a_ingresar = int(input(f"cuantas notas deseas ingresar {ingresa_nombre} (ingresa un numero positivo y menor que 11): "))
        if notas_a_ingresar > 0 and notas_a_ingresar <=10:
            break
        else:
            print("❗ERROR! ingresa un numero valido❗\n")
    except:
        print("❗ERROR! ingresa un valor numerico❗\n") 

# te pido que ingreses tus notas de 0 a 100, despues de ingresar la nota te dice si es insuficiente, suficiente, bueno, muy bueno o sobresaliente
for i in range(notas_a_ingresar):
    while True:
        try:
            valor_de_nota = float(input(f"ingresa tu {i+1} nota {ingresa_nombre}: "))
            if  valor_de_nota >= 0  and valor_de_nota <=100:
                lista_de_notas.append(valor_de_nota)
                break
            else:
                print("❗ERROR!ingresa tu nota nueva mente❗\n")
        except:
            print("❗ERROR! ingresa un valor numerico valido❗\n")


# Calificacion de notas, este condicional sirve para tambien la interacion con el publico ya que como se ve al inicio,
#  yo pido que ingrese diferenste notas , y de acuerdo al valor que ingrese se le va a mostrar las diferentes calificaciones.
    if valor_de_nota >= 0 and valor_de_nota < 59:
        print("*"*30)
        print(f"😓 Insuficiente")
        print("*"*30,"\n")
    elif (valor_de_nota >= 60 and valor_de_nota <= 69):
        print("*"*30)
        print(f"🙂‍ Suficiente")
        print("*"*30,"\n")
    elif (valor_de_nota >= 70 and valor_de_nota <= 79):
        print("*"*30)
        print(f"👍 Bueno")
        print("*"*30,"\n")
    elif (valor_de_nota >= 80 and valor_de_nota <= 89):
        print("*"*30)
        print(f"🙌 Muy Bueno")
        print("*"*30,"\n")
    elif (valor_de_nota >= 90 and valor_de_nota <= 100):
        print("*"*30)
        print(f"🎊 Sobresaliente")
        print("*"*30,"\n")
 
# si el valor de la nota es 1 se termina el ingreso de notas
# esta parte sirve para cuando el usuario solo quiera ingresar una nota le selga primero el tipo de nota que tiene,
#despues de eso el codigo termina aqui ya que lo termino con la funcion exit() que lo termina todo.
if len(lista_de_notas) == 1:
    print(f"ingresaste una sola nota {ingresa_nombre} y es: {lista_de_notas[0]}")
    print("finalizado el ingreso de notas")
    exit()

# va a mostrarle al usuario su promedio de notas despues de haberlas ingresado y eso adicional le va a mostrar,
# la lista de sus notas ya almacenada.
promedio_de_nota = sum(lista_de_notas) / len(lista_de_notas) 
print("="*70)
print(f"Tus notas fueron recogidas y montadas en una lista {ingresa_nombre}. !EXITOSAMENRTE!.")  
print("="*70)
print(f"tu lista de notas es: {lista_de_notas}\n")

# esto es un paso adicionale que agregue para que sea vea mas colorido, esto lo use para que depende el promedio,
# que salga le va a salir el mensaje de aucerdo a su valor.
if promedio_de_nota < 50:
    print("*"*40)
    print(f"tu promedio de notas es de: 😭 {promedio_de_nota:.2f}") 
    print("*"*40,"\n")
elif 50 <= promedio_de_nota <65:  
    print("*"*40)
    print(f"tu promedio de notas es de: 😱 {promedio_de_nota:.2f}") 
    print("*"*40,"\n")
elif 65 <= promedio_de_nota <85:  
    print("*"*40)
    print(f"tu promedio de notas es de: 🥱 {promedio_de_nota:.2f}") 
    print("*"*40,"\n")
elif 85 <= promedio_de_nota <90:  
    print("*"*40)
    print(f"tu promedio de notas es de: 🥳 {promedio_de_nota:.2f}") 
    print("*"*40,"\n")
elif 90 <= promedio_de_nota <=100:  
    print("*"*40)
    print(f"tu promedio de notas es de: 👑 {promedio_de_nota:.2f}") 
    print("*"*40,"\n")
    
# inicio con un while true, para que siempre se ejecute el programa 
while True:
    try:# se usa para controlar los valores que ingrese el usuario y que solo ingrese lo que se pida
        ingresa_numero_mayor_que = float(input(
            f"🔍 ingresa un valor numérico que esté en tus notas {ingresa_nombre}. Notas: {lista_de_notas}\n"
            "Para saber cuáles son mayores que este, ingresa un número (entre 0 a 100): "))
        if 0 <= ingresa_numero_mayor_que <= 100:# condiciona al usuario a solo ingresar un valor entre 0 y 100
            if ingresa_numero_mayor_que in lista_de_notas:# Verifica si el número está en la lista 
                break# frena el bucle despues que la condicion sea verdadera
        #los dos else sirven para los mismo mostrar el error por si el usuario ingresa algo diferente
        #  a lo pedido estos se encargan de los numero que no estan  en la condicion pedida. 
        # si ingresa un valor diferente a 0 o 100.
            else:
                print(f"❗Este número no se encuentra en la lista {lista_de_notas}❗\n")
        else:
            print("❗ERROR! Ingresa un valor entre 0 y 100❗\n")
    except ValueError:# si el usuario ingresa un valor en este caso este elemento se usa solo para los valores 
                     #como texto, y iconos.
        print("❗ERROR! Ingresa un valor numérico válido❗\n")

contador = 0 #inicializo el contador que va a servir para que este tome todos los valores que sean mayor al numero que se ingrese
print("="*40,"\n")
print(f"Notas mayores que {ingresa_numero_mayor_que}:")
# Utilizamos un for para recorrer todas las calificaciones dentro de la lista
for calificacion in lista_de_notas:
    if calificacion > ingresa_numero_mayor_que: # este condicional se usa para comprobar el valor que se ingresa
        # y  diferneciarlo, de acuerdo a los valores que estan en la lista si hay numeros mayores.
        print(f'La calificación {calificacion} es mayor a {ingresa_numero_mayor_que}')
        contador += 1 # va a tomar todos los valores que sean mayor al numero ingresado

print("="*40,"\n")
print(f'Hay {contador} calificaciones mayores que {ingresa_numero_mayor_que}.')
print("="*40,"\n")


# inicio con un while true, para que siempre se ejecute  al inicializar el programa tambien va ser util para que cuando el usaurio ingrese un valor erroneo
# se lo vuelva a pedir hasta que sea correcto. si es correcto lo para con el break que se tiene que colocar donde quieres que termine el bucle
#  cuando la opcion del usuario este correcta.
while True:
    # las linea 145,147,166,168 sirven de la misma manera que lo explique arriba el try para si es verdad lo que se ingresa de acuerdo a la condicion,
    # se va a parar con el break que se coloca para que el bucle no sea infinito y los else y except
    #  son los errores que se muestran si el usuario no cumple con la condicion que se pide.
    try:
        ingresa_numero_igual_que = float(input(f"🔍 acontinuacion ingresa un valor numerico espesifico que deses saber cuantas veces esta en tus notas. {ingresa_nombre}: "))
        if 0 <=  ingresa_numero_mayor_que <=100:
            contador_de_notas = 0 #inicializo el contador que va a servir para que este tome todos los valores que sean igual al numero que se ingrese
            comprobar = False    # False por defecto (asume que no hay coincidencia inicial)
            for numero_igual in lista_de_notas:
                if numero_igual == ingresa_numero_igual_que :
                    contador_de_notas+= 1 # Cuenta cuántas veces aparece el numero que ingresaste a  llista que tienes de notas
                    comprobar = True # Marca que hubo al menos una coincidencia

            if comprobar: # sirve para diferenciar las notas que se ingrese de acuerdo a el valor que ingrese se va a mostrar o el if o else,
                # if se muestra cuando el usuario ingrese un valor que este en la lista de notas de lo contrario va a mostrar el else y
                #  con el while va a pedirle un numero valido hasta que sea el correcto.
                print("="*40)
                print(f'La calificación {ingresa_numero_igual_que} aparece {contador_de_notas} veces en la lista.')
                print("="*40,"\n")
                break
            else:
                print("="*40)
                print(f'La calificación {ingresa_numero_igual_que} no se encontró en la lista.')
                print("="*40,"\n")
        else:
             print("❗ERROR!ingresa un valor entre 0 y 100❗\n")
    except:
        print("❗ERROR! ingresa un valor numerico valido❗\n")


